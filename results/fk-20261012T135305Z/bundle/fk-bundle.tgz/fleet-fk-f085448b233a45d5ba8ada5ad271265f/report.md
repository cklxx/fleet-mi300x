# F/K session result

Status: **completed**.

```json
{
  "status": "completed",
  "arms": {
    "F": {
      "status": "rejected",
      "reason": "F: reader-ready/copy/overlap screen rejected; see F_screens.json"
    },
    "K": {
      "status": "rejected",
      "reason": "K: reader-ready/copy/overlap screen rejected; see K_screens.json"
    },
    "FK": {
      "status": "skipped",
      "reason": "F and K did not both survive"
    }
  },
  "commit": "ce32cd515f705037646cb2db583b788729d76ac1",
  "session_id": "f085448b233a45d5ba8ada5ad271265f"
}
```

Raw stdout/stderr: logs/. Commands/deadlines: steps.json. Graphs/binaries/traces/proofs/layer dumps/pairs: artifacts/.

[U] Single-token traces are attribution screens, not timing verdicts; signal stamps approximate event publication, not hardware cache residency. Task-op/router/logit-margin section 6 subgates have no new per-op dump here. Kept means the documented full-decode gates and paired rule passed; it does not change shipped defaults.
